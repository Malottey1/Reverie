import 'package:flutter/material.dart';
import 'package:reverietest/wishlistnoitems.dart';


class WishlistApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: WishlistScreen(),
      theme: ThemeData(
        primaryColor: const Color.fromARGB(255, 221, 219, 211),
        scaffoldBackgroundColor: const Color.fromARGB(255, 221, 219, 211),
        appBarTheme: AppBarTheme(
          color: const Color.fromARGB(255, 221, 219, 211),
          iconTheme: IconThemeData(color: Colors.black),
          titleTextStyle: TextStyle(
            color: Colors.black,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

class WishlistScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Wishlist', style: TextStyle(fontWeight: FontWeight.bold)),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).push(MaterialPageRoute(builder: (context) => EmptyWishlistScreen()));
          },
        ),
        actions: [
          Stack(
            children: [
              IconButton(
                icon: Icon(Icons.shopping_basket),
                onPressed: () {
                  // Handle shopping basket button press
                },
              ),
              Positioned(
                right: 11,
                top: 11,
                child: Container(
                  padding: EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  constraints: BoxConstraints(
                    minWidth: 14,
                    minHeight: 14,
                  ),
                  child: Text(
                    '1', // This should be dynamically updated based on cart items count
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 8,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      body: ListView(
        padding: EdgeInsets.all(8.0),
        children: [
          WishlistItem(
            imageUrl: 'lib/assets/beosound_headsets.png',
            name: 'Beosound Headsets',
            price: '\$140',
            rating: 5,
          ),
          WishlistItem(
            imageUrl: 'lib/assets/flangesio_sneakers.png',
            name: 'Flangesio Sneakers',
            price: '\$240',
            rating: 4,
          ),
          WishlistItem(
            imageUrl: 'lib/assets/necklace_earring_set.png',
            name: 'Necklace Earring Set',
            price: '\$240',
            rating: 5,
          ),
          WishlistItem(
            imageUrl: 'lib/assets/dellenger_safety_glasses.png',
            name: 'Dellenger Safety Glasses',
            price: '\$40',
            rating: 2,
          ),
          WishlistItem(
            imageUrl: 'lib/assets/generic_mens_leather_jacket.png',
            name: 'Generic Mens Leather Jacket',
            price: '\$400',
            rating: 4,
          ),
        ],
      ),
    );
  }
}

class WishlistItem extends StatelessWidget {
  final String imageUrl;
  final String name;
  final String price;
  final int rating;

  WishlistItem({
    required this.imageUrl,
    required this.name,
    required this.price,
    required this.rating,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color.fromARGB(255, 221, 219, 211),
      elevation: 5,
      margin: EdgeInsets.symmetric(vertical: 8.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10.0),
              child: Image.asset(
                imageUrl,
                width: 80,
                height: 80,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(width: 16.0),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8.0),
                  Row(
                    children: [
                      Text('Review'),
                      SizedBox(width: 4.0),
                      Row(
                        children: List.generate(
                          5,
                          (index) => Icon(
                            index < rating ? Icons.star : Icons.star_border,
                            size: 20,
                            color: Color.fromARGB(255, 105, 115, 78),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    price,
                    style: TextStyle(
                      fontSize: 16.0,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 8.0),
                  ElevatedButton(
                    onPressed: () {
                      // Handle add to cart
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 105, 115, 78),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: Text('Add to Cart', style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}


