import 'package:flutter/material.dart';
import 'package:reverietest/wishlistitems.dart';
// import 'package:reverietest/wishlistnoitems.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nopa Investments',
      home: WishlistApp(),
      debugShowCheckedModeBanner: false,
    );
  }
}